# ValleSalesPro — painel de vendas para Discord

Projeto Node.js 24 com painel web, catálogo, categorias, pedidos, Pix manual/automático via Mercado Pago e atendimento IA opcional.

## O que está incluído
- Site público com apresentação da plataforma e planos mensal, trimestral e teste grátis de 5 dias.
- Login pelo Discord OAuth2.
- Área do proprietário quando o e-mail verificado da sessão corresponde a `PLATFORM_OWNER_EMAIL` (padrão `mivalle209@gmail.com`).
- Edição dos nomes, preços e descrições exibidos nos planos e gestão de administradores da plataforma.
- Painel por servidor com indicadores de faturamento, pedidos, estoque e gráfico mensal.
- Categorias, produtos e escolha de Pix manual/automático por produto.
- Bot Discord com `/loja` e `/painel`, publicação de categorias por canal e tickets privados.
- No Pix manual, o bot não chama a IA. O dono/staff pode confirmar a venda e o bot tenta entregar o item por DM e registra no canal de entregas.
- No Pix automático, o bot cria cobrança Pix no Mercado Pago, mostra QR Code/copia e cola, aguarda confirmação via webhook e tenta enviar a entrega por DM.

## Instalação local
1. Instale Node.js 24.
2. Copie `.env.example` para `.env`.
3. Preencha as variáveis obrigatórias.
4. Execute `npm install` e depois `npm start`.
5. No Discord Developer Portal, configure o OAuth Redirect URI exatamente igual a `DISCORD_REDIRECT_URI`.
6. Ative `Server Members Intent` apenas se necessário; para a IA que lê mensagens de ticket, habilite `Message Content Intent`.
7. Convide o bot com permissões de ver canais, enviar mensagens, gerenciar canais, incorporar links e usar comandos de aplicação.

## Configuração de produtos e entrega
- Crie categoria, depois produto.
- Para produto digital com entrega automática por DM, adicione um código por linha no campo de estoque.
- O estoque é consumido uma vez por entrega; reponha códigos quando necessário.
- Se o comprador bloquear DMs, o bot não consegue garantir o recebimento privado. O canal de entregas registra o resultado quando a integração está ativa.
- O canal de entregas configurado no código é `1530192442958020781`.
- Cargos autorizados para confirmar vendas: dono `1526605050804441220` e staff `1526604871850000476`.

## Variáveis de ambiente
Veja `.env.example`. Nunca publique `.env`, tokens de bot, client secret ou Access Token do Mercado Pago.

## Limitações importantes antes de vender o serviço
- Os planos e preços podem ser editados e são exibidos publicamente, mas **a cobrança recorrente, checkout dos planos, ativação automática de assinatura e expiração de acesso ainda precisam ser implementados e testados**.
- Cada cliente ainda não possui isolamento completo de configuração e armazenamento de token em um sistema SaaS multi-tenant pronto para produção.
- O login do painel exige que as credenciais OAuth estejam configuradas. O proprietário deve usar a conta Discord cujo e-mail verificado seja `mivalle209@gmail.com`.
- Mercado Pago exige credenciais válidas, URL pública HTTPS e webhook acessível. Teste em sandbox antes de aceitar pagamentos reais.
- Para produção, troque `SESSION_SECRET`, use armazenamento de sessão persistente, banco de dados gerenciado, HTTPS, backups e criptografia de segredos.
- Não considere o projeto pronto para venda pública até concluir os testes integrados de login, pagamento, webhook, estoque, entrega por DM e permissões.
