const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");
const dir = path.join(process.cwd(), "data");
const file = path.join(dir, "db.json");
fs.mkdirSync(dir, { recursive: true });
let db = { guilds: {}, products: {}, orders: {}, categoryPosts: {}, categories: {}, platformAdmins: [], platformPlans: { monthly: { name: "Mensal", price: 29.90, days: 30, description: "Acesso completo por 30 dias" }, quarterly: { name: "Trimestral", price: 79.90, days: 90, description: "Acesso completo por 90 dias" }, trial: { name: "Teste grátis", price: 0, days: 5, description: "Experimente por 5 dias" } } };
try { if (fs.existsSync(file)) db = { ...db, ...JSON.parse(fs.readFileSync(file, "utf8")) }; }
catch (e) { console.error("Erro lendo banco local:", e.message); }
function save() {
  const tmp = file + ".tmp";
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2), "utf8");
  fs.renameSync(tmp, file);
}
const makeId = (prefix = "") => prefix + crypto.randomUUID();
module.exports = { db, save, makeId };
