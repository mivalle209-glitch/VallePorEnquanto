require("dotenv").config();
const express = require("express");
const session = require("express-session");
const helmet = require("helmet");
const crypto = require("node:crypto");
const { db, save, makeId } = require("./db");
const { startBot, OWNER_ROLE_ID, STAFF_ROLE_ID, DELIVERY_CHANNEL_ID } = require("./discord");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BASE_URL = (process.env.BASE_URL || `http://localhost:${PORT}`).replace(/\/$/, "");
const MP_API = "https://api.mercadopago.com";

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.urlencoded({ extended: false, limit: "100kb" }));
app.use(express.json({ limit: "100kb" }));
app.use(session({
  name: "vallesalespro.sid",
  secret: process.env.SESSION_SECRET || "DEV-ONLY-change-this-before-deploy",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: BASE_URL.startsWith("https://"), maxAge: 8 * 60 * 60 * 1000 }
}));
app.use("/static", express.static(require("node:path").join(__dirname, "../public")));

const esc = s => String(s ?? "").replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
const money = n => Number(n || 0).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
const shell = (title, body, req) => `<!doctype html><html lang="pt-br"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${esc(title)} · ValleSalesPro</title><link rel="stylesheet" href="/static/styles.css"></head><body><header><a class="brand" href="/">VALLE<span>SALES</span>PRO</a><nav>${req.session.user ? `<span class="muted">${esc(req.session.user.username)}</span><a href="/dashboard">Painel</a><a href="/logout">Sair</a>` : `<a href="/auth/discord">Entrar com Discord</a>`}</nav></header><main>${body}</main><footer>ValleSalesPro · Node.js 24</footer></body></html>`;
const send = (res, title, body, req) => res.send(shell(title, body, req));
const auth = (req, res, next) => req.session.user ? next() : res.redirect("/auth/discord");
const flash = req => req.query.ok ? `<p class="notice">Salvo com sucesso.</p>` : req.query.err ? `<p class="error">${esc(req.query.err)}</p>` : "";
function cfg(gid) {
  if (!db.guilds[gid]) db.guilds[gid] = { storeName: "Minha loja", paymentMethod: "mp", pixKey: "", pixName: "", pixInstructions: "Envie o comprovante para o suporte.", pixQrUrl: "", mpAccessToken: "", channelId: "", admins: [] };
  return db.guilds[gid];
}
const getProducts = gid => Object.values(db.products).filter(p => p.guildId === gid);
const getCategories = gid => Object.values(db.categories || {}).filter(c => c.guildId === gid);
const guildOrders = gid => Object.values(db.orders || {}).filter(o => o.guildId === gid);
const isPaid = o => ["paid", "completed"].includes(o.status);
const totalRevenue = orders => orders.filter(isPaid).reduce((sum,o) => sum + Number(o.amount || 0), 0);
const monthRevenue = (orders, monthOffset=0) => { const now = new Date(); const d = new Date(now.getFullYear(), now.getMonth()+monthOffset, 1); return orders.filter(o => isPaid(o) && new Date(o.paidAt || o.completedAt || o.createdAt) >= d && new Date(o.paidAt || o.completedAt || o.createdAt) < new Date(d.getFullYear(),d.getMonth()+1,1)).reduce((s,o)=>s+Number(o.amount||0),0); };
const salesChart = orders => { const values=[]; const now=new Date(); for(let i=5;i>=0;i--){ const d=new Date(now.getFullYear(),now.getMonth()-i,1); const label=d.toLocaleDateString("pt-BR",{month:"short"}).replace(".",""); const val=orders.filter(o=>isPaid(o)&&new Date(o.paidAt||o.completedAt||o.createdAt)>=d&&new Date(o.paidAt||o.completedAt||o.createdAt)<new Date(d.getFullYear(),d.getMonth()+1,1)).reduce((a,o)=>a+Number(o.amount||0),0); values.push({label,val}); } const max=Math.max(1,...values.map(x=>x.val)); return `<div class="chart-bars">${values.map(x=>`<div class="bar-col"><div class="bar-value">${money(x.val)}</div><div class="bar-track"><div class="bar-fill" style="height:${Math.max(3,x.val/max*100)}%"></div></div><small>${esc(x.label)}</small></div>`).join("")}</div>`; };
const isPlatformOwner = req => Boolean(req.session.user?.verified) && String(req.session.user?.email || "").toLowerCase() === String(process.env.PLATFORM_OWNER_EMAIL || "mivalle209@gmail.com").toLowerCase();
const isPlatformAdmin = req => isPlatformOwner(req) || (db.platformAdmins || []).includes(String(req.session.user?.email || "").toLowerCase());
const getGuilds = req => (req.session.guilds || []).filter(g => isPlatformAdmin(req) || g.owner || ((BigInt(g.permissions || "0") & 0x20n) === 0x20n));
const ownedGuild = (req, gid) => getGuilds(req).find(g => g.id === gid);
function guildGuard(req, res, next) {
  const gid = String(req.params.gid || req.body.guildId || req.query.guildId || "");
  if (!gid || !ownedGuild(req, gid)) return res.status(403).send(shell("Acesso negado", `<section class="panel"><h1>Acesso negado</h1><p>Você precisa ter Gerenciar Servidor no Discord.</p><a class="btn" href="/dashboard">Voltar</a></section>`, req));
  req.guildId = gid; req.guild = ownedGuild(req, gid); req.config = cfg(gid); next();
}
async function mpRequest(token, path, options = {}) {
  const r = await fetch(MP_API + path, { ...options, headers: { Authorization: `Bearer ${token}`, "Content-Type": "application/json", ...(options.headers || {}) } });
  const text = await r.text();
  let data = {};
  try { data = text ? JSON.parse(text) : {}; } catch {}
  if (!r.ok) throw new Error(data.message || data.error || `Mercado Pago respondeu HTTP ${r.status}`);
  return data;
}
async function fulfill(order, payment) {
  if (!order || order.status === "paid") return;
  if (payment.status !== "approved") return;
  if (String(payment.external_reference || "") !== order.id) return;
  if (Number(payment.transaction_amount).toFixed(2) !== Number(order.amount).toFixed(2)) return;
  const product = db.products[order.productId];
  if (!product || product.guildId !== order.guildId) return;
  order.status = "paid"; order.paymentId = String(payment.id); order.paidAt = new Date().toISOString();
  if (product.stock && product.stock.length) {
    order.delivery = product.stock.shift();
    product.stockCount = product.stock.length;
  } else {
    order.delivery = null;
    order.deliveryNote = "Pagamento confirmado, mas o estoque acabou. Contate o vendedor.";
  }
  save();
  if (botClient && order.channelId) { const ch = await botClient.channels.fetch(order.channelId).catch(() => null); if (ch?.isTextBased()) await ch.send(`✅ **Pagamento confirmado automaticamente pelo Mercado Pago.** Pedido \`${order.id}\`. A entrega está sendo processada.`).catch(() => {}); }
  // O comprador recebe o código por DM; se DMs estiverem fechadas, o pedido continua salvo.
  if (botClient && order.discordUserId && order.delivery) {
    const u = await botClient.users.fetch(order.discordUserId).catch(() => null);
    if (u) {
      const delivered = await u.send(`Pagamento confirmado! Seu pedido **${String(product.name).replace(/[*_`]/g, "")}** foi aprovado.\nPedido: ${order.id}\nSua entrega: \`${String(order.delivery).replace(/`/g, "")}\``).then(()=>true).catch(()=>false);
      order.dmDelivered = delivered; save();
    }
  }
  if (botClient) {
    const ch = await botClient.channels.fetch(DELIVERY_CHANNEL_ID).catch(()=>null);
    if (ch?.isTextBased()) await ch.send({embeds:[{title:"Pagamento automático confirmado",description:`Produto: **${String(product.name).replace(/[*_`]/g, "")}**\nCliente: <@${order.discordUserId}>\nValor: ${money(order.amount)}\nPedido: \`${order.id}\`\nEntrega por DM: ${order.delivery ? (order.dmDelivered ? "enviada" : "não enviada — DM fechada ou erro") : "sem estoque cadastrado"}`,color:0x36b37e}]}).catch(()=>{});
  }
}
let botClient = null;

app.get("/", (req, res) => {
  const plans = db.platformPlans || {};
  const planCard = (key, fallback, featured=false) => { const p=plans[key]||fallback; return `<article class="plan-card ${featured?'featured':''}"><div class="plan-label">${esc(p.name)}</div><div class="plan-price">${Number(p.price||0)===0?'Grátis':money(p.price)}<small> / ${key==='monthly'?'mês':key==='quarterly'?'3 meses':'5 dias'}</small></div><p>${esc(p.description||'Acesso à plataforma ValleSalesPro.')}</p><ul><li>Catálogo e categorias</li><li>Tickets privados no Discord</li><li>Pix manual ou automático por produto</li><li>Painel de vendas e estoque</li></ul><a class="btn ${featured?'btn-light':''}" href="/auth/discord">${key==='trial'?'Começar teste grátis':'Começar agora'}</a></article>`; };
  send(res, "Plataforma de vendas Discord", `<section class="hero hero-home"><div class="eyebrow"><span class="live-dot"></span> PLATAFORMA PARA LOJAS DISCORD</div><div class="hero-layout"><div><h1>Sua loja no Discord.<br><span>Em outro nível.</span></h1><p>Venda produtos digitais com tickets privados, pagamentos configuráveis, entrega organizada e métricas em um só painel.</p><div class="hero-actions"><a class="btn btn-large" href="/auth/discord">Acessar painel <span>↗</span></a><a class="text-link" href="#recursos">Conhecer recursos ↓</a></div><div class="trust-row"><span>✓ Configuração guiada</span><span>✓ Controle de estoque</span><span>✓ Pix por produto</span></div></div><div class="mock-dashboard"><div class="mock-top"><span class="mock-dot"></span><span class="mock-dot"></span><span class="mock-dot"></span><span class="mock-title">Visão geral · ValleSalesPro</span></div><div class="mock-kpis"><div><small>Vendas totais</small><b>R$ 2.840,00</b><em>↗ painel de vendas</em></div><div><small>Pedidos</small><b>128</b><em>em um só lugar</em></div></div><div class="mock-chart"><div class="chart-caption"><b>Desempenho da loja</b><small>Últimos 6 meses</small></div><div class="mock-bars">${[32,49,38,65,52,86,70,94,61,76,88,100].map((v,i)=>`<i style="height:${v}%"></i>`).join('')}</div></div><div class="mock-ticket"><span class="ticket-icon">✓</span><div><b>Pedido #VS-2048</b><small>Pagamento confirmado · Entrega enviada</small></div><span class="status-pill">Concluído</span></div></div></div></section><section id="recursos" class="section-block"><div class="section-heading"><div class="eyebrow">FEITO PARA VENDER</div><h2>Mais controle. Menos trabalho manual.</h2><p>Ferramentas para organizar sua operação e oferecer uma experiência de compra profissional.</p></div><div class="feature-grid"><article class="feature-card"><span class="feature-icon">▦</span><h3>Catálogo organizado</h3><p>Crie categorias, cadastre produtos e publique sua loja nos canais que escolher.</p></article><article class="feature-card"><span class="feature-icon">↗</span><h3>Pagamentos flexíveis</h3><p>Escolha Pix manual ou automático para cada produto, conforme sua operação.</p></article><article class="feature-card"><span class="feature-icon">◎</span><h3>Entrega controlada</h3><p>Gerencie estoque digital, acompanhe pedidos e envie entregas por mensagem privada quando possível.</p></article><article class="feature-card"><span class="feature-icon">✦</span><h3>IA para atendimento</h3><p>Atendimento assistido por IA nos tickets automáticos, com o modo manual reservado à equipe.</p></article><article class="feature-card"><span class="feature-icon">▤</span><h3>Métricas de vendas</h3><p>Acompanhe faturamento, pedidos, produtos e evolução mensal no painel.</p></article><article class="feature-card"><span class="feature-icon">⌘</span><h3>Equipe e permissões</h3><p>Organize quem administra a plataforma e quem atende as vendas do servidor.</p></article></div></section><section class="pricing-section"><div class="section-heading"><div class="eyebrow">PLANOS</div><h2>Comece no seu ritmo.</h2><p>Escolha a duração que combina com sua loja. Os valores exibidos são configuráveis pelo proprietário.</p></div><div class="pricing-grid">${planCard('monthly',{name:'Mensal',price:29.9,description:'Flexibilidade para sua loja.'})}${planCard('quarterly',{name:'Trimestral',price:79.9,description:'Mais tempo para crescer.'},true)}${planCard('trial',{name:'Teste grátis',price:0,description:'Conheça a plataforma por 5 dias.'})}</div><p class="pricing-note">Os planos são exibidos para apresentação. A cobrança e ativação automática de assinaturas precisam ser conectadas antes da venda pública.</p></section><section class="closing-cta"><div><div class="eyebrow">PRONTO PARA COMEÇAR?</div><h2>Organize sua loja com o ValleSalesPro.</h2><p>Entre com sua conta Discord e configure seu servidor.</p></div><a class="btn btn-large" href="/auth/discord">Acessar painel ↗</a></section>`, req);
});
app.get("/auth/discord", (req, res) => {
  if (!process.env.DISCORD_CLIENT_ID || !process.env.DISCORD_REDIRECT_URI) return send(res, "Configuração necessária", `<section class="panel"><h1>Configure o .env</h1><p>Preencha as credenciais Discord antes de entrar.</p></section>`, req);
  const stateToken = crypto.randomBytes(18).toString("hex"); req.session.oauthState = stateToken;
  const q = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, redirect_uri: process.env.DISCORD_REDIRECT_URI, response_type: "code", scope: "identify email guilds", state: stateToken });
  res.redirect("https://discord.com/oauth2/authorize?" + q.toString());
});
app.get("/auth/discord/callback", async (req, res) => {
  try {
    if (!req.query.code || req.query.state !== req.session.oauthState) return res.status(400).send("Login inválido. Tente novamente.");
    const form = new URLSearchParams({ client_id: process.env.DISCORD_CLIENT_ID, client_secret: process.env.DISCORD_CLIENT_SECRET, grant_type: "authorization_code", code: String(req.query.code), redirect_uri: process.env.DISCORD_REDIRECT_URI });
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", { method: "POST", headers: { "Content-Type": "application/x-www-form-urlencoded" }, body: form });
    const tokens = await tokenRes.json();
    if (!tokenRes.ok) throw new Error(tokens.error_description || "Falha no OAuth");
    const headers = { Authorization: `Bearer ${tokens.access_token}` };
    const [uRes, gRes] = await Promise.all([fetch("https://discord.com/api/users/@me", { headers }), fetch("https://discord.com/api/users/@me/guilds", { headers })]);
    const user = await uRes.json(), guilds = await gRes.json();
    if (!uRes.ok || !gRes.ok || !Array.isArray(guilds)) throw new Error("Não foi possível consultar sua conta Discord.");
    req.session.user = { id: user.id, username: user.global_name || user.username, avatar: user.avatar, email: user.email || "", verified: Boolean(user.verified) };
    req.session.guilds = guilds;
    delete req.session.oauthState;
    res.redirect("/dashboard");
  } catch (e) { console.error(e); res.status(500).send(shell("Erro de login", `<section class="panel"><h1>Não consegui entrar</h1><p>${esc(e.message)}</p><a href="/auth/discord">Tentar novamente</a></section>`, req)); }
});
app.get("/logout", (req,res) => req.session.destroy(() => res.redirect("/")));

app.get("/dashboard", auth, (req,res) => {
  const gs = getGuilds(req), owner=isPlatformOwner(req), visibleGuildIds = new Set(gs.map(g=>g.id));
  const allOrders = Object.values(db.orders||{}).filter(o=>owner || visibleGuildIds.has(o.guildId)), paid = allOrders.filter(isPaid), plans=db.platformPlans||{};
  const ownerPanel = owner ? `<section class="panel owner-panel"><div class="panel-heading"><div><div class="eyebrow">CONTROLE DA PLATAFORMA</div><h2>Área do proprietário</h2><p class="muted">Acesso exclusivo de ${esc(process.env.PLATFORM_OWNER_EMAIL||'mivalle209@gmail.com')}.</p></div><span class="status-pill">Proprietário</span></div><form class="plan-editor" method="post" action="/platform/plans"><div class="plan-edit-head"><h3>Planos e preços</h3><span class="muted">Altere como os planos aparecem no site</span></div>${['monthly','quarterly','trial'].map((key)=>{const p=plans[key]||{};return `<div class="plan-edit-row"><div><b>${key==='monthly'?'Plano mensal':key==='quarterly'?'Plano trimestral':'Teste grátis'}</b><small>${key==='monthly'?'Acesso por 30 dias':key==='quarterly'?'Acesso por 90 dias':'Acesso por 5 dias'}</small></div><label>Nome<input name="${key}_name" value="${esc(p.name||'')}" required maxlength="40"></label><label>Preço (R$)<input name="${key}_price" type="number" min="0" step="0.01" value="${Number(p.price||0).toFixed(2)}" required></label><label>Descrição<input name="${key}_description" value="${esc(p.description||'')}" maxlength="120"></label></div>`}).join('')}<button class="btn">Salvar planos</button></form><div class="admin-manager"><div><h3>Administradores</h3><p class="muted">Adicione e remova quem pode administrar a plataforma.</p></div><form method="post" action="/platform/admins" class="inline-form"><input type="email" name="email" required placeholder="admin@exemplo.com"><button class="btn">Adicionar admin</button></form><div class="admin-list">${(db.platformAdmins||[]).map(email=>`<div class="admin-row"><span>${esc(email)}</span><form method="post" action="/platform/admins/remove"><input type="hidden" name="email" value="${esc(email)}"><button class="danger">Remover</button></form></div>`).join('')||'<p class="muted">Nenhum administrador adicional.</p>'}</div></div></section>` : '';
  const chart= salesChart(allOrders);
  send(res, "Visão geral", `${flash(req)}<div class="dashboard-head"><div><div class="eyebrow">WORKSPACE</div><h1>Bem-vindo, ${esc(req.session.user.username)}</h1><p class="muted">Acompanhe seus resultados e gerencie suas lojas.</p></div><div class="avatar-chip">${esc((req.session.user.username||'U').slice(0,1).toUpperCase())}</div></div><div class="stats-grid"><article class="stat-card"><span>Faturamento confirmado</span><b>${money(totalRevenue(allOrders))}</b><small>Pedidos pagos ou concluídos</small></article><article class="stat-card"><span>Pedidos confirmados</span><b>${paid.length}</b><small>Em todos os pedidos registrados</small></article><article class="stat-card"><span>Pedidos em andamento</span><b>${allOrders.filter(o=>!isPaid(o)&&!['error','payment_error','cancelled'].includes(o.status)).length}</b><small>Aguardando pagamento ou equipe</small></article><article class="stat-card"><span>Servidores acessíveis</span><b>${gs.length}</b><small>Com permissão de configuração</small></article></div><div class="dashboard-grid"><section class="panel chart-panel"><div class="panel-heading"><div><h2>Visão de faturamento</h2><p class="muted">Últimos seis meses · valores confirmados</p></div><span class="chart-tag">BRL</span></div>${chart}</section><section class="panel quick-panel"><div class="panel-heading"><div><h2>Atalhos</h2><p class="muted">O que você pode fazer agora</p></div></div><a class="quick-link" href="#servers"><span>＋</span><div><b>Configurar servidor</b><small>Produtos, categorias e pagamentos</small></div><strong>→</strong></a><a class="quick-link" href="#servers"><span>▤</span><div><b>Gerenciar catálogo</b><small>Estoque e métodos de pagamento</small></div><strong>→</strong></a><a class="quick-link" href="#servers"><span>◷</span><div><b>Ver pedidos</b><small>Conferir pedidos e entregas</small></div><strong>→</strong></a></section></div>${ownerPanel}<section id="servers" class="servers-section"><div class="panel-heading"><div><div class="eyebrow">SEUS SERVIDORES</div><h2>Gerenciar lojas</h2><p class="muted">Escolha um servidor para abrir o painel completo.</p></div></div><div class="server-grid">${gs.map(g=>`<article class="server-card"><div class="server-avatar">${esc((g.name||'D').slice(0,1).toUpperCase())}</div><div class="server-info"><h3>${esc(g.name)}</h3><small>ID ${esc(g.id)}</small></div><a class="btn" href="/guild/${g.id}">Abrir painel →</a></article>`).join('')||'<div class="empty-state"><h3>Nenhum servidor disponível</h3><p>Adicione o bot ao seu servidor e confirme que sua conta tem permissão de Gerenciar Servidor.</p></div>'}</div></section>`, req);
});
app.get("/guild/:gid", auth, guildGuard, (req,res) => {
  const ps = getProducts(req.guildId);
  const orders = guildOrders(req.guildId), paidOrders=orders.filter(isPaid), pendingOrders=orders.filter(o=>!isPaid(o)&&!['error','payment_error','cancelled'].includes(o.status));
  send(res, "Configurar loja", `${flash(req)}<div class="dashboard-head"><div><div class="eyebrow">CONFIGURAÇÃO DO SERVIDOR</div><h1>${esc(req.guild.name)}</h1><p class="muted">Catálogo, pagamentos, estoque e desempenho da sua loja.</p></div><a class="btn" href="/dashboard">← Visão geral</a></div><div class="stats-grid"><article class="stat-card"><span>Faturamento confirmado</span><b>${money(totalRevenue(orders))}</b><small>Vendas pagas</small></article><article class="stat-card"><span>Pedidos concluídos/pagos</span><b>${paidOrders.length}</b><small>Pedidos confirmados</small></article><article class="stat-card"><span>Aguardando ação</span><b>${pendingOrders.length}</b><small>Pagamentos e atendimentos</small></article><article class="stat-card"><span>Produtos cadastrados</span><b>${ps.length}</b><small>Itens no catálogo</small></article></div><div class="dashboard-grid"><section class="panel chart-panel"><div class="panel-heading"><div><h2>Faturamento mensal</h2><p class="muted">Evolução das vendas confirmadas</p></div></div>${salesChart(orders)}</section><section class="panel"><h2>Pedidos recentes</h2>${orders.slice().sort((a,b)=>new Date(b.createdAt)-new Date(a.createdAt)).slice(0,6).map(o=>`<div class="order-row"><div><b>${esc(o.productName)}</b><small>${esc(o.id)} · ${new Date(o.createdAt).toLocaleDateString('pt-BR')}</small></div><div class="order-right"><b>${money(o.amount)}</b><small class="status-text">${esc(o.status)}</small></div></div>`).join('')||'<p class="muted">As vendas aparecerão aqui quando houver pedidos.</p>'}</section></div><div class="grid"><section class="panel"><h2>Configuração da loja</h2><form method="post" action="/guild/${req.guildId}/settings">
  <label>Nome da loja<input name="storeName" maxlength="70" required value="${esc(req.config.storeName)}"></label>
  <label>Meio principal de pagamento<select name="paymentMethod"><option value="mp" ${req.config.paymentMethod==="mp"?"selected":""}>Mercado Pago (checkout automático)</option><option value="pix" ${req.config.paymentMethod==="pix"?"selected":""}>Pix manual</option><option value="nubank" ${req.config.paymentMethod==="nubank"?"selected":""}>Nubank Pix manual</option></select></label>
  <label>Chave Pix<input name="pixKey" value="${esc(req.config.pixKey)}" placeholder="CPF, e-mail, telefone ou chave aleatória"></label>
  <label>Nome do recebedor<input name="pixName" value="${esc(req.config.pixName)}"></label>
  <label>QR Code Pix (URL HTTPS de imagem, opcional)<input name="pixQrUrl" value="${esc(req.config.pixQrUrl)}" placeholder="https://..."></label>
  <label>Instruções Pix manual<textarea name="pixInstructions" rows="3">${esc(req.config.pixInstructions)}</textarea></label>
  <label>Access Token privado do Mercado Pago<input type="password" name="mpAccessToken" value="" autocomplete="new-password" placeholder="${req.config.mpAccessToken ? "Token já configurado — deixe vazio para manter" : "APP_USR-..."}"></label>
  <p class="muted">Token salvo apenas no servidor. Nunca envie esse token para clientes.</p><button class="btn">Salvar configurações</button></form></section>
  <section class="panel"><h2>Categorias</h2><form method="post" action="/guild/${req.guildId}/categories"><label>Nome da categoria<input name="name" maxlength="60" required placeholder="Robux, Contas, Itens..."></label><button class="btn">Criar categoria</button></form><p class="muted">Depois de criar, escolha a categoria no produto e use <code>/painel</code> no Discord para escolher em qual canal publicá-la.</p>${getCategories(req.guildId).map(c=>`<div class="product"><div><b>${esc(c.name)}</b><p class="muted">Canal: ${c.channelId ? `<#${esc(c.channelId)}>` : "Ainda não publicado"}</p></div><form method="post" action="/guild/${req.guildId}/categories/${c.id}/delete"><button class="danger">Excluir</button></form></div>`).join("") || "<p>Nenhuma categoria criada.</p>"}</section>
  <section class="panel"><h2>Produtos</h2><form method="post" action="/guild/${req.guildId}/products">
  <label>Nome<input name="name" required maxlength="100"></label><label>Descrição<input name="description" maxlength="240"></label><label>Preço em reais<input name="price" type="number" min="0.01" step="0.01" required></label>
  <label>Categoria<select name="categoryId" required>${getCategories(req.guildId).map(c=>`<option value="${esc(c.id)}">${esc(c.name)}</option>`).join("")}</select></label><label>Forma de pagamento deste produto<select name="paymentMode"><option value="manual">Pix manual — equipe confere</option><option value="automatic">Automático — Mercado Pago</option></select></label><label>Estoque de entrega (um código por linha)<textarea name="stock" rows="4" placeholder="CODIGO-001&#10;CODIGO-002"></textarea></label>
  <button class="btn">Adicionar produto</button></form></section></div>
  <section class="panel"><h2>Catálogo (${ps.length})</h2>${ps.map(p=>`<div class="product"><div><b>${esc(p.name)}</b><p>${esc(p.category || db.categories[p.categoryId]?.name || "Sem categoria")} · ${money(p.price)} · ${p.paymentMode === "automatic" ? "Mercado Pago automático" : "Pix manual"} · Estoque: ${(p.stock||[]).length}</p><small>${esc(p.description)}</small></div><form method="post" action="/guild/${req.guildId}/products/${p.id}/delete"><button class="danger">Excluir</button></form></div>`).join("") || "<p>Nenhum produto cadastrado.</p>"}</section>
  <section class="panel"><h2>Pedidos manuais</h2>${Object.values(db.orders).filter(o=>o.guildId===req.guildId && ["manual_pending","awaiting_manual_payment"].includes(o.status)).map(o=>`<div class="product"><div><b>${esc(o.productName)}</b><p>${money(o.amount)} · Pedido ${esc(o.id)}</p><small>Cliente Discord: ${esc(o.discordUserId)}</small></div><form method="post" action="/guild/${req.guildId}/orders/${o.id}/approve"><button class="btn">Confirmar recebimento e entregar</button></form></div>`).join("") || "<p>Nenhum pagamento manual aguardando confirmação.</p>"}</section>`, req);
});
app.post("/platform/admins", auth, (req,res) => {
  if (!isPlatformOwner(req)) return res.status(403).send("Apenas o proprietário da plataforma pode gerenciar administradores.");
  const email=String(req.body.email||"").trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.redirect("/dashboard?err=E-mail%20inválido");
  if (email !== String(process.env.PLATFORM_OWNER_EMAIL||"mivalle209@gmail.com").toLowerCase()) { db.platformAdmins=db.platformAdmins||[]; if(!db.platformAdmins.includes(email)) db.platformAdmins.push(email); save(); }
  res.redirect("/dashboard?ok=1");
});
app.post("/platform/admins/remove", auth, (req,res) => {
  if (!isPlatformOwner(req)) return res.status(403).send("Apenas o proprietário da plataforma pode gerenciar administradores.");
  const email=String(req.body.email||"").trim().toLowerCase(); db.platformAdmins=(db.platformAdmins||[]).filter(e=>e!==email); save(); res.redirect("/dashboard?ok=1");
});

app.post("/platform/plans", auth, (req,res) => {
  if (!isPlatformOwner(req)) return res.status(403).send("Apenas o proprietário pode configurar os planos.");
  const next={};
  for(const key of ["monthly","quarterly","trial"]) {
    const price=Number(req.body[`${key}_price`]);
    if(!Number.isFinite(price)||price<0||price>100000) return res.redirect("/dashboard?err=Preço%20inválido");
    next[key]={name:String(req.body[`${key}_name`]||"").trim().slice(0,40)||({monthly:"Mensal",quarterly:"Trimestral",trial:"Teste grátis"}[key]),price:Math.round(price*100)/100,days:key==="monthly"?30:key==="quarterly"?90:5,description:String(req.body[`${key}_description`]||"").trim().slice(0,120)};
  }
  db.platformPlans=next; save(); res.redirect("/dashboard?ok=1");
});

app.post("/guild/:gid/settings", auth, guildGuard, (req,res) => {
  const c = req.config;
  c.storeName = String(req.body.storeName || "Minha loja").slice(0,70);
  c.paymentMethod = ["mp","pix","nubank"].includes(req.body.paymentMethod) ? req.body.paymentMethod : "mp";
  c.pixKey = String(req.body.pixKey || "").slice(0,200);
  c.pixName = String(req.body.pixName || "").slice(0,100);
  c.pixInstructions = String(req.body.pixInstructions || "").slice(0,1000);
  c.pixQrUrl = String(req.body.pixQrUrl || "").startsWith("https://") ? String(req.body.pixQrUrl).slice(0,500) : "";
  if (req.body.mpAccessToken) c.mpAccessToken = String(req.body.mpAccessToken).trim();
  save(); res.redirect(`/guild/${req.guildId}?ok=1`);
});
app.post("/guild/:gid/categories", auth, guildGuard, (req,res) => {
  const name = String(req.body.name || "").trim().slice(0,60);
  if (!name) return res.redirect(`/guild/${req.guildId}?err=Nome%20da%20categoria%20obrigatório`);
  if (getCategories(req.guildId).some(c=>c.name.toLowerCase()===name.toLowerCase())) return res.redirect(`/guild/${req.guildId}?err=Essa%20categoria%20já%20existe`);
  const c = { id: makeId("cat_"), guildId: req.guildId, name, channelId: "", createdAt: new Date().toISOString() };
  db.categories[c.id] = c; save(); res.redirect(`/guild/${req.guildId}?ok=1`);
});
app.post("/guild/:gid/categories/:cid/delete", auth, guildGuard, (req,res) => {
  const c=db.categories[req.params.cid];
  if(c && c.guildId===req.guildId) {
    const used=getProducts(req.guildId).some(p=>p.categoryId===c.id);
    if(used) return res.redirect(`/guild/${req.guildId}?err=Remova%20os%20produtos%20dessa%20categoria%20antes`);
    delete db.categories[c.id]; save();
  }
  res.redirect(`/guild/${req.guildId}?ok=1`);
});
app.post("/guild/:gid/products", auth, guildGuard, (req,res) => {
  const price = Number(req.body.price);
  if (!Number.isFinite(price) || price <= 0 || price > 1000000) return res.redirect(`/guild/${req.guildId}?err=Preço%20inválido`);
  const category = db.categories[String(req.body.categoryId||"")];
  if (!category || category.guildId !== req.guildId) return res.redirect(`/guild/${req.guildId}?err=Crie%20e%20selecione%20uma%20categoria`);
  const p = { id: makeId("p_"), guildId: req.guildId, name: String(req.body.name||"Produto").slice(0,100), description: String(req.body.description||"").slice(0,240), categoryId: category.id, category: category.name, paymentMode: req.body.paymentMode === "automatic" ? "automatic" : "manual", price: Math.round(price*100)/100, stock: String(req.body.stock||"").split(/\r?\n/).map(s=>s.trim()).filter(Boolean).slice(0,1000), createdAt: new Date().toISOString() };
  db.products[p.id] = p; save(); res.redirect(`/guild/${req.guildId}?ok=1`);
});
app.post("/guild/:gid/products/:pid/delete", auth, guildGuard, (req,res) => {
  const p = db.products[req.params.pid];
  if (p && p.guildId === req.guildId) { delete db.products[p.id]; save(); }
  res.redirect(`/guild/${req.guildId}?ok=1`);
});
app.post("/guild/:gid/orders/:oid/approve", auth, guildGuard, async (req,res) => {
  const o = db.orders[req.params.oid];
  if (!o || o.guildId !== req.guildId || !["manual_pending","awaiting_manual_payment"].includes(o.status)) return res.redirect(`/guild/${req.guildId}?err=Pedido%20inválido`);
  const p = db.products[o.productId];
  if (!p) return res.redirect(`/guild/${req.guildId}?err=Produto%20não%20encontrado`);
  o.status = "paid"; o.paidAt = new Date().toISOString();
  p.stock = Array.isArray(p.stock) ? p.stock : [];
  o.delivery = p.stock.length ? p.stock.shift() : null;
  if (!o.delivery) o.deliveryNote = "Pagamento confirmado, mas não havia estoque. Contate o vendedor.";
  save();
  if (botClient && o.delivery) { const u = await botClient.users.fetch(o.discordUserId).catch(()=>null); if (u) { o.dmDelivered = await u.send(`Pagamento confirmado para ${String(p.name).replace(/[*_`]/g,"")}. Pedido ${o.id}. Sua entrega: \`${String(o.delivery).replace(/`/g,"")}\``).then(()=>true).catch(()=>false); save(); } }
  res.redirect(`/guild/${req.guildId}?ok=1`);
});

app.get("/buy/:pid", async (req,res) => {
  const p = db.products[req.params.pid]; if (!p) return res.status(404).send("Produto não encontrado.");
  const c = cfg(p.guildId);
  const discordUserId = String(req.query.u || "");
  if (!/^\d{17,20}$/.test(discordUserId)) return res.status(400).send("Abra a compra pelo botão no Discord para identificar sua conta.");
  const order = { id: makeId("ord_"), guildId:p.guildId, productId:p.id, productName:p.name, amount:p.price, discordUserId, status:"pending", createdAt:new Date().toISOString() };
  db.orders[order.id] = order; save();
  if ((p.paymentMode === "automatic" || (!p.paymentMode && c.paymentMethod === "mp")) && c.mpAccessToken) {
    try {
      const pref = await mpRequest(c.mpAccessToken, "/checkout/preferences", { method:"POST", body: JSON.stringify({
        items:[{ title:p.name, description:p.description || p.category, quantity:1, currency_id:"BRL", unit_price:p.price }],
        external_reference:order.id,
        notification_url:`${BASE_URL}/webhooks/mercadopago`,
        back_urls:{ success:`${BASE_URL}/order/${order.id}`, pending:`${BASE_URL}/order/${order.id}`, failure:`${BASE_URL}/order/${order.id}` },
        auto_return:"approved",
        metadata:{ order_id:order.id, guild_id:p.guildId }
      })});
      order.preferenceId = pref.id; save();
      return res.redirect(pref.init_point || pref.sandbox_init_point);
    } catch(e) { order.status="error"; order.error=e.message; save(); return res.status(502).send(shell("Erro de pagamento", `<section class="panel"><h1>Não consegui criar o checkout</h1><p>${esc(e.message)}</p><p>Peça ao vendedor para conferir o Access Token no painel.</p></section>`, req)); }
  }
  order.status = "manual_pending"; save();
  const qr = c.pixQrUrl ? `<img class="qr" src="${esc(c.pixQrUrl)}" alt="QR Code Pix">` : "";
  return res.send(shell("Pagar por Pix", `<section class="panel"><h1>${esc(p.name)}</h1><h2>${money(p.price)}</h2><p>Pagamento por ${c.paymentMethod==="nubank"?"Nubank Pix":"Pix manual"}</p>${qr}<p><b>Recebedor:</b> ${esc(c.pixName || "Conferir com vendedor")}</p><p><b>Chave Pix:</b> <code>${esc(c.pixKey || "Ainda não configurada")}</code></p><p>${esc(c.pixInstructions)}</p><p>Depois de pagar, envie o comprovante ao suporte do servidor. A entrega só acontece após conferência e confirmação manual.</p><p class="muted">Pedido ${esc(order.id)}</p></section>`, req));
});
app.get("/order/:oid", (req,res) => {
  const o = db.orders[req.params.oid]; if (!o) return res.status(404).send("Pedido não encontrado.");
  send(res, "Pedido", `<section class="panel"><h1>Pedido ${esc(o.id)}</h1><p>Produto: ${esc(o.productName)}</p><p>Valor: ${money(o.amount)}</p><p>Status atual: <b>${esc(o.status)}</b></p><p>O retorno do checkout não confirma o pagamento por si só. A confirmação ocorre pelo webhook/API.</p>${o.status==="paid"?"<p>Pagamento confirmado. Se a entrega não chegou por DM, contate o vendedor.</p>":""}</section>`, req);
});
app.post("/webhooks/mercadopago", async (req,res) => {
  res.sendStatus(200);
  try {
    const type = req.query.type || req.body.type || req.body.action;
    const paymentId = req.query["data.id"] || req.body?.data?.id || req.body?.id;
    if (!paymentId || (type && !String(type).includes("payment"))) return;
    // Primeiro localiza o pedido pelo external_reference só depois de consultar o pagamento.
    // O token é selecionado pela referência obtida do pagamento autenticado.
    const tokens = Object.values(db.guilds).map(c=>c.mpAccessToken).filter(Boolean);
    for (const token of tokens) {
      try {
        const payment = await mpRequest(token, `/v1/payments/${encodeURIComponent(paymentId)}`);
        const order = db.orders[payment.external_reference];
        if (order) { await fulfill(order, payment); break; }
      } catch {}
    }
  } catch(e) { console.error("Webhook Mercado Pago:", e.message); }
});

app.use((req,res) => res.status(404).send(shell("Não encontrado", `<section class="panel"><h1>Página não encontrada</h1><a href="/">Voltar ao início</a></section>`, req)));

async function run() {
  if (process.env.DISCORD_BOT_TOKEN && process.env.DISCORD_CLIENT_ID) {
    botClient = await startBot({ token: process.env.DISCORD_BOT_TOKEN, clientId: process.env.DISCORD_CLIENT_ID, db, save, cfg, getProducts, makeId, baseUrl: BASE_URL });
  } else console.warn("Discord não iniciado: configure DISCORD_BOT_TOKEN e DISCORD_CLIENT_ID no .env");
  app.listen(PORT, () => console.log(`ValleSalesPro rodando em ${BASE_URL}`));
}
run().catch(e => { console.error(e); process.exit(1); });
